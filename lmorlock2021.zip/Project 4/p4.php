<!DOCTYPE html>	<!-- p4.php -->
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title>Project 4: Guessing Game</title>

   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
         rel="stylesheet" crossorigin="anonymous"
         integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3">
   
   <link href="../index.css" rel="stylesheet">
   <link href="p4.css" rel="stylesheet">
</head>

<body>
<header class="container-fluid">
   <div class="row">
      <div class="col-lg-12">
         <h1 class="display-1">Project 4: Guessing Game</h1>
      </div>
   </div>
</header>

<div class="container-fluid navbar">
	<a href="../index.html" class="needs_padding">Home</a>
	<a href="https://llmresume.weebly.com/" target="blank" class="needs_padding">Project 1</a>
	<a href="../p3/index.html" class="needs_padding">Project 3</a>
        <a href="index.html" class="needs_padding">Project 4</a>
</div>

<div class="container-fluid extra-padding col-lg-offset-3 col-lg-5 col-md-offset-3 col-md-5 col-sm-offset-3 col-sm-5">
   <h1>Welcome to my Guessing Game!</h1>
</div>

<div class="container-fluid col-lg-offset-4 col-lg-4 col-md-offset-4 col-md-4 col-sm-offset-4 col-sm-4">
  <form method="post" action="p4.php">
    <p>I'm thinking of a number between 1 and 10.</p>
    <p>You have 5 guesses to get it.</p>
    <p>Your guess? <input type="number" name="num" min="1" max="10" autofocus></p>
    <input type="submit" id="GuessButton" value="Guess">
  </form>
</div>

<div class="container-fluid extra-padding col-lg-offset-3 col-lg-5 col-md-offset-3 col-md-5 col-sm-offset-3 col-sm-5s">
<?php 
//allows for tracking of the variables between guess button clicks
session_start();	
   //if the variables have been unset, initialize them
   if ($_SESSION["numTriesLeft"] == NULL) {
        $_SESSION["numTriesLeft"] = 5;
        $_SESSION["numTriesTotal"] = 0;
        $_SESSION["randNum"] = rand(1, 10);
   }

   //if user clicks guess button
   if ($_SERVER["REQUEST_METHOD"] == "POST") {

      //triesTotal and triesLeft are automatically updated
      $_SESSION["numTriesTotal"]++;
      $_SESSION["numTriesLeft"]--;

      //if user does not enter anything, un-update triesTotal and Left, have user try again
      if ($_POST["num"] == "") {
         $_SESSION["numTriesTotal"]--;
         $_SESSION["numTriesLeft"]++;
         echo "<p>You didn't type a number, please try again!</p>";
         echo "<p>You still have " . $_SESSION["numTriesLeft"] . " tries left.</p>";
         echo '<div><img src="pawse_right_there_criminal_scum.jpg" alt="dog holding up paw" class="rounded mx-auto d-block"></div>';
      }
      //user has correctly guessed the number, stop game
      else if ($_SESSION["randNum"] == $_POST["num"]) {
         echo "<h2>Correct!</h2>";
         echo "<p>You guessed the number in " . $_SESSION["numTriesTotal"] . " tries</p>";
         echo "<p>To play again, just enter another guess!</p>";
         echo '<div><img src="party_dog_winner.jpg" alt="happy dog with party hat" class="rounded mx-auto d-block"></div>';
         unset($_SESSION["numTriesLeft"]);
         unset($_SESSION["numTriesTotal"]);
         unset($_SESSION["randNum"]);
      }
      //user failed to guess number, stop game
      else if ($_SESSION["numTriesLeft"] == 0) {
         echo "<p>I was thinking of " . $_SESSION["randNum"] . " :(</p>";
         echo "<p>It's okay though, you're still a winner in my heart.</p>";
         echo "<p>To play again, just enter another guess!</p>";
         echo '<div><img src="party_dog_sad.jpg" alt="sad dog with party hat" class="rounded mx-auto d-block"></div>';
         unset($_SESSION["numTriesLeft"]);
         unset($_SESSION["numTriesTotal"]);
         unset($_SESSION["randNum"]);
      }
      //give user a hint to the number
      else if(($_SESSION["randNum"] > $_POST["num"]) && ($_SESSION["numTriesLeft"] != 0)) {
         echo "<p>Too low! You have " . $_SESSION["numTriesLeft"] . " guesses left</p>";
         echo '<div><img src="dog_too_low_rotated.jpg" alt="dog looking down" class="rounded mx-auto d-block"></div>';
      }
      else if(($_SESSION["randNum"] < $_POST["num"]) && ($_SESSION["numTriesLeft"] != 0)) {
         echo "<p>Too high! You have " . $_SESSION["numTriesLeft"] . " guesses left</p>";
         echo '<div><img src="dog_too_high.jpg" alt="dog looking up" class="rounded mx-auto d-block"></div>';
      } 

   }	//end big if
?>
</div>

<footer class="container-fluid">
   <p>Made by Lauren, 2022</p>
   <p><em>Last updated 07112022</em></p>
</footer>

</body>

</html>